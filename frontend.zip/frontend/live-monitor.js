
const refreshButton = document.getElementById("refreshButton");
const connectionStatus = document.getElementById("connectionStatus");
const emptyMessage = document.getElementById("emptyMessage");

refreshButton.addEventListener("click", () => {
  connectionStatus.textContent = "Backend not connected";
  emptyMessage.textContent =
    "The monitoring backend and WebRTC signaling are not configured yet.";

  document.getElementById("activeCount").textContent = "—";
  document.getElementById("violationCount").textContent = "—";
  document.getElementById("streamCount").textContent = "0";

  console.info(
    "ExamShield: frontend loaded. Real monitoring requires backend integration."
  );
});
